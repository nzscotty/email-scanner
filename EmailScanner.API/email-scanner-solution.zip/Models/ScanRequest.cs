namespace EmailScanner.API.Models;

public class ScanRequest
{
    public string EmailText { get; set; } = string.Empty;
}